import os

DATA_DIR = "data"

OUTPUTS_DIR = "outputs"
RESULTS_DIR = os.path.join(OUTPUTS_DIR, "results")
FIGURES_DIR = os.path.join(OUTPUTS_DIR, "figures")
LOGS_DIR = os.path.join(OUTPUTS_DIR, "logs")
